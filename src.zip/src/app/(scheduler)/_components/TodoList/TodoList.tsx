const TodoList = () => {
  return <section className=" bg-slate-500">TodoList</section>;
};

export default TodoList;
