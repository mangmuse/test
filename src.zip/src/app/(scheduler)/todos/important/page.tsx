import Page from "@/components/Page";

const ImportantTodosPage = () => {
  return <Page title="중요 일정보기">important page</Page>;
};

export default ImportantTodosPage;
