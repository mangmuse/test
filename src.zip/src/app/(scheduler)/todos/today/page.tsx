import Page from "@/components/Page";

const TodayTodosPage = () => {
  return <Page title="투두 페이지">todo page</Page>;
};

export default TodayTodosPage;
