import Page from "@/components/Page";

const SharedCalendarPage = () => {
  return <Page title="공유 캘린더">공유 캘린더 페이지</Page>;
};

export default SharedCalendarPage;
