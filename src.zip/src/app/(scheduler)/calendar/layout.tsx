import { PropsWithChildren } from "react";

const CalendarLayout = ({ children }: PropsWithChildren) => {
  return <section>{children}</section>;
};

export default CalendarLayout;
