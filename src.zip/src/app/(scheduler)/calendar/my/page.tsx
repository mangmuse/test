import Page from "@/components/Page";

const MyCalendarPage = () => {
  return <Page title="내 일정보기">내 캘린더 페이지 내용</Page>;
};

export default MyCalendarPage;
