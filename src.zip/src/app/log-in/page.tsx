"use client";
const LogInPage = () => {
  const handleLogIn = async () => {
    try {
      const res = await fetch("http://localhost:3000/api/log-in");
      if (!res.ok) {
        throw new Error("Failed to log in");
      }
      const data = await res.json();
    } catch (error) {
      console.error("Error during login:", error);
    }
  };
  return (
    <>
      로그인페이지에요
      <button onClick={handleLogIn}>로그인 버튼이에요</button>
    </>
  );
};

export default LogInPage;
